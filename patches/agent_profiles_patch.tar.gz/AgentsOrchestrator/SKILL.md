---
name: AgentsOrchestrator
summary: 全局调度与流水线编排的技能说明
---

SOP:
1. 读取 task-ledger 并优先级打分
2. 按依赖图分解任务并分配至合适 agent
3. 对每个子任务设定质量门禁
4. 任务完成后写入 Hindsight，并调用 Learner 进行模式抽取

Interfaces:
- /task-ledger/read
- /task-assign (agent_id, task_id, constraints)
- /hindsight/append (event)

自省触发条件：任务失败、QA 未通过、超时、用户纠正。

验证：通过生成 sample task 并运行本地排期模拟，检查任务流转与门禁逻辑。