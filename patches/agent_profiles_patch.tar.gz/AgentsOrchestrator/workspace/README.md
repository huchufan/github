---
title: README
date: 2026-09-11
updated: 2026-09-11
category: 
status: draft
tags: []
---

AgentsOrchestrator workspace

用途：存放当前编排的 task-ledger、schedules、run-logs。
示例文件：
- task-ledger.yaml
- schedule.gantt.md
- run-logs/*.log

备注：所有变更需记录到 Hindsight。
