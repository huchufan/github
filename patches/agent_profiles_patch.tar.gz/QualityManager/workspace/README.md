QualityManager workspace

用途：存放测试用例、结果、故障回溯与质量仪表盘。
示例：
- tests/
- results/2026-09-11-qa.json
- dashboards/quality.html

注意：每个失败用例必须关联 Hindsight 事件 ID。