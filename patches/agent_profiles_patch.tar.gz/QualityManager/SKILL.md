---
title: SKILL
date: 2026-09-11
updated: 2026-09-11
category: 
status: draft
tags: []
name: QualityManager
summary: 质量管理与测试策略 SOP
---

SOP:
1. 定义测试矩阵并分配给 EvidenceQA / API Tester
2. 收集测试结果并执行根因分析
3. 对重复失败形成 KB 条目与回归测试
4. 写入 Hindsight 并触发 Architect/CodeEngineer 升级

验证：质量门禁策略在样本流水线上阻止不合格任务推进。
