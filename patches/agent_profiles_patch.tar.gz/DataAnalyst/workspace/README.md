DataAnalyst workspace

用途：存放数据集、notebooks、分析脚本与临时输出。
示例文件：
- datasets/
- notebooks/analysis-2026-09-11.ipynb
- tests/test_data_pipeline.py

注意：输出报告需附上数据版本与处理流水线记录。