---
name: DataAnalyst
summary: 数据分析与报告的技能模板
---

SOP:
1. 拉取指定数据集并验证 schema
2. 执行清洗与质量检查（缺失、异常值、重复）
3. 根据任务选择统计方法与可视化
4. 产出结论并写入 /hindsight/analysis 和 /kb/insights

Verification:
- 提交 notebook，运行 `python -m pytest tests/test_data_pipeline.py` 应全部通过。

接口：/datasets/fetch, /analysis/run, /reports/generate