CodeEngineer workspace

用途：代码、tests、ci 模板。
示例：
- src/
- tests/
- .github/workflows/template.yml

要求：所有实现提交前必须通过本地 pytest 与 lint。