---
name: CodeEngineer
summary: 代码实现与测试的技能模板
---

SOP:
1. 根据 ArchitectUX 的接口契约生成最小可行实现
2. 为新功能先写失败的测试（TDD）
3. 实现代码并确保 tests 通过
4. 生成微变更的 commit 并记录到 Hindsight

验证命令示例:
- run tests: `pytest -q` → expect `0 failed` for module
- lint: `flake8 src/` → expect `no errors`