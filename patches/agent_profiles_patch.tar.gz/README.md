---
title: README
date: 2026-09-11
updated: 2026-09-11
category: 
status: draft
tags: []
---

Agent Profiles Index

列出了基于风格文件生成的 agent profiles：

- AgentsOrchestrator (总调度智能体)
- IntelligenceCollector (情报收集智能体)
- DataAnalyst (智能数据分析助手)
- ArchitectUX (架构师智能体)
- CodeEngineer (代码工程师智能体)
- OfficeDocAssistant (办公文档处理智能体)
- QualityManager (质量管理智能体)
- PPTDesigner (PPT 设计智能体)
- DefaultAgent (默认智能体)

每个 profile 包含：profile.yaml、soul.md、SKILL.md、workspace/README.md

位置：./agent_profiles/<profile>/
