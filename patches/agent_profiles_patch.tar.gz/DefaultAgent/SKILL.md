---
name: DefaultAgent
summary: 通用智能体模板
---

SOP:
1. 接收任务并尝试解析需求
2. 若超出能力范围，标记并上报给 Orchestrator
3. 任意变更都写入 Hindsight

验证：接收示例任务并成功生成首轮交付物或升级请求。