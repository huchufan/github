DefaultAgent workspace

用途：临时任务与通用工具脚本。