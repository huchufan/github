ArchitectUX workspace

用途：存放架构文档、diagram、接口契约样例。
示例文件：
- docs/architecture.md
- diagrams/system-2026-09-11.svg
- contracts/api-v1-openapi.yaml

交付：所有交付物需可被 CodeEngineer 直接引用实现。