---
title: SKILL
date: 2026-09-11
updated: 2026-09-11
category: 
status: draft
tags: []
name: ArchitectUX
summary: 系统与产品架构设计 SOP
---

SOP:
1. 读取需求规格并列出关键非功能需求
2. 提出 2-3 个可选架构方案并评估 tradeoffs
3. 选择方案并输出接口契约、数据模型与部署建议
4. 写入 KB 并生成验证任务交给 CodeEngineer

验证：架构交付物应包含 UML/序列图、API contract 示例和性能估计。
