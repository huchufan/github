---
name: PPTDesigner
summary: 高质量 PPT 设计 SOP
---

SOP:
1. 根据项目背景生成 3 种备选大纲
2. 选定大纲后输出每页要点与视觉草图
3. 生成 PPTX 并提供审阅备注
4. 记录设计 rationale 到 Hindsight

验证：检查导出 PPTX 中含有指定模板与公司徽标。