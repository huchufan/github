PPTDesigner workspace

用途：存放 design-templates、exports 和 review-notes。
示例：
- templates/company.pptx
- exports/project-pitch-2026-09-11.pptx
- review/notes-2026-09-11.md

输出：每次导出需记录设计 rationale 与来源素材。