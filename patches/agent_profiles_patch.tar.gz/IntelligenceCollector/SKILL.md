---
name: IntelligenceCollector
summary: 情报抓取、核验与结构化输出
---

SOP:
1. 按 schedule 拉取已登记的数据源
2. 对条目做去重、时间戳化、来源标注
3. 多源核验规则：至少两来源匹配或标注为待核验
4. 输出情报条目并写入 /hindsight/events 与 /kb/pending

Interfaces:
- /collector/schedule
- /collector/run (source_id)
- /hindsight/append (event)

验证：用 3 个不同公开源做同一事件抓取；检查最终情报条目包含三项元数据（来源、时间、置信度）。