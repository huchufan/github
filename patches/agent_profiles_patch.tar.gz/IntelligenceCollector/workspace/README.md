IntelligenceCollector workspace

用途：存放抓取脚本、raw/ 子目录保存原始素材、processed/ 保存结构化条目。
示例文件：
- sources.yaml
- raw/2026-09-11-sourceA.json
- processed/entries-2026-09-11.ndjson

日志：logs/*.log 需每日轮转并备份到 Hindsight。