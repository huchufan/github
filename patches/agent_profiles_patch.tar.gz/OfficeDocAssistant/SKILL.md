---
name: OfficeDocAssistant
summary: 办公文档自动化处理技能
---

SOP:
1. 接收文档任务与模板
2. 生成初稿并标注关键假设
3. 根据反馈进行迭代并记录变更历史
4. 输出最终格式并写入 Hindsight

验证：比对模板与生成文档头部元数据一致。