OfficeDocAssistant workspace

用途：存放模板、草稿、审核记录和最终文档。
示例：
- templates/company-template.md
- drafts/project-plan-draft.md
- finals/project-plan-final.pdf

注意：所有文档变更需写变更日志并关联 Hindsight 事件。